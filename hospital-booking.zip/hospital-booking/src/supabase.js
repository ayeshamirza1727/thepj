import { createClient } from "@supabase/supabase-js";

const supabaseUrl = "https://exahfqdrgyndsdepgnju.supabase.co";
const supabaseKey = "sb_publishable_spx-SIzAOsoFtHP_24mEsQ_E0W_Dqbo";

export const supabase = createClient(
  supabaseUrl,
  supabaseKey
);