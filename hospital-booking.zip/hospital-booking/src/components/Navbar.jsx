import { Link } from "react-router-dom";

function Navbar() {
  return (
    <nav className="navbar">
      <h2>CAREPLUS HOSPITAL</h2>

      <div className="navbar-links">
        <Link to="/">Home</Link>
        <Link to="/doctors">Doctors</Link>
        <Link to="/appointment">Book Appointment</Link>
        <Link to="/history">Appointment History</Link>
      </div>
    </nav>
  );
}

export default Navbar;