function DoctorCard({ name, specialization, experience }) {
  return (
    <div className="doctor-card">
      <h2>{name}</h2>
      <p>Specialization: {specialization}</p>
      <p>Experience: {experience}</p>
    </div>
  );
}

function Doctors() {
  return (
    <main className="doctors-page">
      <h1>Our Doctors</h1>

      <div className="doctors-grid">
        <DoctorCard
          name="Dr. Anil Kumar"
          specialization="Cardiology"
          experience="12 Years"
        />

        <DoctorCard
          name="Dr. Priya Sharma"
          specialization="Dermatology"
          experience="8 Years"
        />

        <DoctorCard
          name="Dr. Rahul Verma"
          specialization="Orthopedics"
          experience="10 Years"
        />

        <DoctorCard
          name="Dr. Sneha Rao"
          specialization="Pediatrics"
          experience="7 Years"
        />
      </div>
    </main>
  );
}

export default Doctors;