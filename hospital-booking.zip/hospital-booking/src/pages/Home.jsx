import { Link } from "react-router-dom";

function Home() {
  return (
    <main className="home-page">
      <h1>Welcome to CarePlus Hospital</h1>

      <p>
        Providing quality healthcare with experienced doctors and
        easy appointment booking.
      </p>

      <p>
        Choose a doctor and book your appointment quickly and easily.
      </p>

      <Link to="/appointment">
        <button>Book an Appointment</button>
      </Link>
    </main>
  );
}

export default Home;