import { useState } from "react";
import { supabase } from "../supabase";

function Appointment() {
  const [patientName, setPatientName] = useState("");
  const [doctor, setDoctor] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [reason, setReason] = useState("");

  async function handleAppointment() {
    if (!patientName || !doctor || !date || !time || !reason) {
      alert("Please fill all the details");
      return;
    }

    const { error } = await supabase
      .from("appointments")
      .insert([
        {
          patient_name: patientName,
          doctor: doctor,
          date: date,
          time: time,
          reason: reason,
        },
      ]);

    if (error) {
      console.error(error);
      alert("Appointment failed: " + error.message);
      return;
    }

    alert("Appointment booked successfully!");

    setPatientName("");
    setDoctor("");
    setDate("");
    setTime("");
    setReason("");
  }

  return (
    <main className="appointment-page">
      <h1>Book an Appointment</h1>

      <div className="appointment-form">
        <label>Patient Name</label>
        <input
          type="text"
          value={patientName}
          onChange={(e) => setPatientName(e.target.value)}
          placeholder="Enter your name"
        />

        <label>Doctor</label>
        <select
          value={doctor}
          onChange={(e) => setDoctor(e.target.value)}
        >
          <option value="">Select Doctor</option>
          <option value="Dr. Anil Kumar">Dr. Anil Kumar</option>
          <option value="Dr. Priya Sharma">Dr. Priya Sharma</option>
          <option value="Dr. Rahul Verma">Dr. Rahul Verma</option>
          <option value="Dr. Sneha Rao">Dr. Sneha Rao</option>
        </select>

        <label>Date</label>
        <input
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
        />

        <label>Time</label>
        <select
          value={time}
          onChange={(e) => setTime(e.target.value)}
        >
          <option value="">Select Time</option>
          <option value="10:00 AM">10:00 AM</option>
          <option value="11:00 AM">11:00 AM</option>
          <option value="2:00 PM">2:00 PM</option>
          <option value="4:00 PM">4:00 PM</option>
        </select>

        <label>Reason for Visit</label>
        <textarea
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          placeholder="Enter reason for appointment"
        ></textarea>

        <button onClick={handleAppointment}>
          Book Appointment
        </button>
      </div>
    </main>
  );
}

export default Appointment;