import { useEffect, useState } from "react";
import { supabase } from "../supabase";

function AppointmentHistory() {
  const [appointments, setAppointments] = useState([]);

  async function getAppointments() {
    const { data, error } = await supabase
      .from("appointments")
      .select("*");

    if (error) {
      console.error(error);
      alert("Failed to retrieve appointments");
      return;
    }

    setAppointments(data);
  }

  useEffect(() => {
    getAppointments();
  }, []);

  return (
    <main className="history-page">
      <h1>Appointment History</h1>

      {appointments.map((appointment) => (
        <div className="appointment-card" key={appointment.id}>
          <h2>{appointment.patient_name}</h2>
          <p>Doctor: {appointment.doctor}</p>
          <p>Date: {appointment.date}</p>
          <p>Time: {appointment.time}</p>
          <p>Reason: {appointment.reason}</p>
        </div>
      ))}
    </main>
  );
}

export default AppointmentHistory;